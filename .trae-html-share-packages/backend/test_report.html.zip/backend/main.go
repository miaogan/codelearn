package main

import (
	"fmt"
	"log"

	"codelearn/config"
	"codelearn/eino"
	"codelearn/handler"
	"codelearn/model"
	"codelearn/repository"
	"codelearn/router"
	"codelearn/service"

	"github.com/glebarez/sqlite"
	"gorm.io/gorm"
)

func main() {
	cfg := config.Load()

	// 初始化数据库（SQLite，纯 Go 驱动，无需 CGO）
	db, err := gorm.Open(sqlite.Open(cfg.DBPath), &gorm.Config{})
	if err != nil {
		log.Fatalf("数据库连接失败: %v", err)
	}

	// 自动迁移表结构
	if err := db.AutoMigrate(
		&model.User{}, &model.Course{}, &model.Unit{},
		&model.Lesson{}, &model.Exercise{}, &model.UserProgress{},
		&model.Submission{}, &model.WrongExercise{},
		&model.XPEvent{}, &model.Exam{}, &model.ExamQuestion{},
		&model.ExamSubmission{}, &model.Certificate{},
		&model.AnalyticsEvent{}, &model.UserFeedback{},
		&model.Achievement{},
	); err != nil {
		log.Fatalf("数据库迁移失败: %v", err)
	}

	// 初始化各层
	repo := repository.New(db)

	// 从 XP 流水对账用户总 XP（保证顶栏与今日进度同口径）
	if err := repo.RebuildUserXP(); err != nil {
		log.Printf("XP 对账警告: %v", err)
	}

	courseSvc := service.NewCourseService(repo)
	progressSvc := service.NewProgressService(repo, cfg.XPPerLesson, cfg.XPPerExercise, cfg.MaxHearts)
	wrongSvc := service.NewWrongExerciseService(repo)
	srsSvc := service.NewSRSReviewService(repo)
	achievementSvc := service.NewAchievementService(repo)
	weeklySvc := service.NewWeeklyReportService(repo)
	examSvc := service.NewExamService(repo)
	leaderboardSvc := service.NewLeaderboardService(repo)
	certSvc := service.NewCertificateService(repo)
	skillSvc := service.NewSkillMapService(repo)
	analyticsSvc := service.NewAnalyticsService(repo)
	generator := eino.NewExerciseGenerator(cfg)

	// Eino 组件初始化
	adaptiveAdvisor := eino.NewAdaptiveAdvisor(cfg)
	tutorAgent := eino.NewTutorAgent(cfg)
	knowledgeRAG := eino.NewKnowledgeRAG(cfg, repo)

	// 初始化处理器
	authHandler := handler.NewAuthHandler(repo, cfg.JWTSecret, cfg.MaxHearts, analyticsSvc)
	courseHandler := handler.NewCourseHandler(courseSvc)
	exerciseHandler := handler.NewExerciseHandler(courseSvc, progressSvc, generator, achievementSvc)
	codeHandler := handler.NewCodeHandler(courseSvc, progressSvc, analyticsSvc, achievementSvc)
	progressHandler := handler.NewProgressHandler(progressSvc)
	wrongHandler := handler.NewWrongExerciseHandler(wrongSvc, srsSvc)
	adaptiveHandler := handler.NewAdaptiveHandler(adaptiveAdvisor, repo)
	tutorHandler := handler.NewTutorHandler(tutorAgent)
	knowledgeHandler := handler.NewKnowledgeHandler(knowledgeRAG)
	examHandler := handler.NewExamHandler(examSvc, progressSvc, certSvc, analyticsSvc, achievementSvc)
	leaderboardHandler := handler.NewLeaderboardHandler(leaderboardSvc)
	certHandler := handler.NewCertificateHandler(certSvc)
	skillHandler := handler.NewSkillHandler(skillSvc)
	analyticsHandler := handler.NewAnalyticsHandler(analyticsSvc, cfg.AdminToken)
	achievementHandler := handler.NewAchievementHandler(achievementSvc)
	weeklyHandler := handler.NewWeeklyReportHandler(weeklySvc)

	// 初始化路由
	r := router.Setup(cfg, authHandler, courseHandler, exerciseHandler, codeHandler, progressHandler, wrongHandler, adaptiveHandler, tutorHandler, knowledgeHandler, examHandler, leaderboardHandler, certHandler, skillHandler, analyticsHandler, achievementHandler, weeklyHandler)

	// 种子数据
	if err := seedData(repo); err != nil {
		log.Printf("种子数据初始化警告: %v", err)
	}

	addr := fmt.Sprintf(":%s", cfg.Port)
	log.Printf("🚀 CodeLearn 服务启动: http://localhost:%s", cfg.Port)
	log.Printf("   API 文档: http://localhost:%s/api/courses", cfg.Port)
	if cfg.LLMEnabled() {
		log.Printf("   AI 习题生成: 已启用 (模型: %s)", cfg.LLMModel)
	} else {
		log.Printf("   AI 习题生成: 未启用 (请设置 LLM_API_KEY 环境变量)")
	}

	if err := r.Run(addr); err != nil {
		log.Fatalf("服务启动失败: %v", err)
	}
}
